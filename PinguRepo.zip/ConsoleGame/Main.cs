﻿using System;
using System.Collections.Generic;
using ConsoleGame.Managers;

namespace ConsoleGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Game myGame = new Game();
            myGame.Run();
        }
    }
}
